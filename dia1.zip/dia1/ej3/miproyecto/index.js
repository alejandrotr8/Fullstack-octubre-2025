let prompt = require('prompt-sync')();

let numero = parseInt(prompt("ingrese un numero: "));
let numero2 = parseInt(prompt("ingrese otro numero: "));

let resultado = numero + numero2;

console.log(resultado);