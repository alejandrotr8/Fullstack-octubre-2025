for (let i = 0; i < 5; i++){
    let text = "";
    for(let j = 0; j < 5; j++){
        text += "**"
    }
    console.log(text);
}