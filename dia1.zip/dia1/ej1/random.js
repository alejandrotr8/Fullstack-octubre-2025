const numeroAleatorio = Math.floor(Math.random() * (500 - 50 + 1)) + 50;
console.log("Número aleatorio entre 50 y 500:", numeroAleatorio);